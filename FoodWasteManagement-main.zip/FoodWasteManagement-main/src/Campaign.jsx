import React from 'react'
import Card from "./Card";
// import Footer from "./Footer";




const Campaign = () =>{
  return (
      <>
      
      <div className="my-5">

      </div>
      <div className='container-fluid mb-5'>
        <div className='row'>
          <div className='col-10 mx-auto'>
            <div className='row gy-6'>
          
        <Card/>
         

            </div>
          </div>
        </div>
      </div>



    </>
  );
};

export default Campaign;